import React from "react";

const SellerFooter = () => {
  return (
    <div class="wrapper">
      <footer class="page-footer">
        <p class="mb-0">Copyright © 2024. All right reserved.</p>
      </footer>
    </div>
  );
};

export default SellerFooter;
